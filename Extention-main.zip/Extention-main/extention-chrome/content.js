(function () {
  if (document.getElementById("fc-floating-btn")) return;

  // =====================================================================
  // Config + state
  // =====================================================================
  const KEY = "fcState";
  const ME = "You";
  const MAX_FILE_MB = 8;
  const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

  // Chats, groups and messages live in chrome.storage.local, so every tab
  // sees the same conversations and updates live.
  const LIB = "__library__";
  const defaultState = () => ({
    dark: false,
    library: [],
    chats: [],
  });

  let state = defaultState();
  // Per-tab UI state (not shared between tabs)
  let isOpen = false;
  let view = "list"; // "list" | "chat"
  let activeId = null;
  let listFilter = "";
  let draft = null; // a dropped video staged in the message box: { media }
  let chatSub = "chats"; // "chats" | "sent" (inside the Chat tab)
  let tab = "chat"; // "chat" | "media" | "groups" | "shares" | "tools"
  let msgFilter = "";

  // =====================================================================
  // Transport hook: swap this for a WebSocket / Firebase / your API so that
  // messages reach other people. Right now everything is local to this browser.
  // =====================================================================
  const transport = {
    send(chat, message) {
      /* e.g. socket.send(JSON.stringify({ chatId: chat.id, message })) */
    },
  };

  // =====================================================================
  // Helpers
  // =====================================================================
  function h(tag, props = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === "class") el.className = v;
      else if (k === "text") el.textContent = v;
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) el.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid);
    return el;
  }

  const fmtTime = (ts) => new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const getChat = (id) => state.chats.find((c) => c.id === id);
  const lastMsg = (c) => c.messages[c.messages.length - 1];

  function save() {
    try {
      chrome.storage.local.set({ [KEY]: state });
    } catch (e) {
      console.warn("Floating Chat: extension was reloaded, refresh this tab.", e);
    }
  }

  // Normalizes saved data and removes the old built-in Assistant chat.
  function normalize(saved) {
    const next = { ...defaultState(), ...saved };
    next.library = next.library || [];
    for (const c of next.chats || []) {
      if (c.id !== "assistant") continue;
      for (const m of c.messages || []) if (m.media) next.library.push({ id: m.id, ts: m.ts, media: m.media });
    }
    next.chats = (next.chats || []).filter((c) => c.id !== "assistant");
    return next;
  }

  function load() {
    try {
      chrome.storage.local.get(KEY).then((res) => {
        if (res[KEY]) {
          const hadAssistant = (res[KEY].chats || []).some((c) => c.id === "assistant");
          state = normalize(res[KEY]);
          if (hadAssistant) save();
        }
        render();
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes[KEY] && changes[KEY].newValue) {
          state = normalize(changes[KEY].newValue);
          if (activeId && !getChat(activeId)) {
            activeId = null;
            view = "list";
          }
          render();
        }
      });
    } catch (e) {
      render();
    }
  }

  // =====================================================================
  // DOM skeleton
  // =====================================================================
  const btn = h("button", { id: "fc-floating-btn", type: "button", "aria-label": "Open chat", text: "💬" });

  const titleEl = h("span", { id: "fc-title", text: "Chat Everywhere" });
  const backBtn = h("button", { id: "fc-back", class: "fc-icon", "aria-label": "Back to chats", text: "‹" });
  const menuBtn = h("button", { id: "fc-menu-btn", class: "fc-icon", "aria-label": "Tools", text: "⋯" });
  const closeBtn = h("button", { id: "fc-chatbox-close", class: "fc-icon", "aria-label": "Close chat", text: "✕" });
  const header = h("div", { id: "fc-chatbox-header" }, backBtn, titleEl, menuBtn, closeBtn);

  // List view
  const searchChats = h("input", { id: "fc-search", type: "text", placeholder: "Search chats" });
  const newBtn = h("button", { class: "fc-pill", text: "+ Chat" });
  const listTop = h("div", { class: "fc-list-top" }, searchChats, newBtn);
  const tabContent = h("div", { id: "fc-tab-content" });
  const TABS = [
    ["chat", "💬", "Chat"],
    ["media", "🖼", "Media"],
    ["groups", "👥", "Groups"],
    ["shares", "🔗", "Shares"],
    ["tools", "🧰", "Tools"],
  ];
  const nav = h(
    "div",
    { id: "fc-nav", role: "tablist" },
    TABS.map(([id, icon, label]) =>
      h(
        "button",
        {
          class: "fc-navbtn",
          type: "button",
          role: "tab",
          "data-tab": id,
          onclick: () => {
            tab = id;
            listFilter = "";
            searchChats.value = "";
            render();
          },
        },
        h("span", { class: "fc-nav-icon", text: icon }),
        h("span", { text: label })
      )
    )
  );
  // Quick composer: type and send without opening a chat first
  const quickInput = h("input", { id: "fc-quick-input", type: "text", placeholder: "Type a message..." });
  const quickSendBtn = h("button", { id: "fc-quick-send", type: "button", text: "Send" });
  const quickEmojiBtn = h("button", {
    id: "fc-quick-emoji",
    type: "button",
    title: "Emoji",
    "aria-label": "Emoji",
    text: "☺",
    onclick: () => {
      quickInput.value += "🙂";
      quickInput.focus();
    },
  });
  const quickChip = h("div", { class: "fc-chip", style: "display:none" });
  const quickBar = h("div", { id: "fc-quick" }, quickChip, h("div", { class: "fc-quick-row" }, quickEmojiBtn, quickInput, quickSendBtn));
  let quickTarget = null; // default recipient for the home-screen message box
  const lastOpened = { dm: null, group: null };
  const listView = h("div", { id: "fc-list-view" }, nav, listTop, tabContent, quickBar);

  // Chat view
  const msgSearchInput = h("input", { id: "fc-msg-search-input", type: "text", placeholder: "Search this chat" });
  const msgSearch = h("div", { id: "fc-msg-search", style: "display:none" }, msgSearchInput);
  const messagesEl = h("div", { id: "fc-chatbox-messages" });
  const toolBtn = (icon, label, title, fn) =>
    h("button", { class: "fc-tool", type: "button", title, onclick: fn }, h("span", { class: "fc-tool-icon", text: icon }), h("span", { text: label }));
  const attachBtn = toolBtn("📎", "Media", "Attach images, video, audio or files", () => fileInput.click());
  const toolbar = h(
    "div",
    { id: "fc-toolbar" },
    attachBtn,
    toolBtn("📸", "Screenshot", "Screenshot this page", () => takeScreenshot()),
    toolBtn("🔗", "Page", "Share this page", () => sharePage()),
    toolBtn("❝", "Quote", "Quote selected text", () => quoteSelection()),
    toolBtn("🔍", "Search", "Search in chat", () => toggleMsgSearch())
  );
  const fileInput = h("input", { type: "file", multiple: true, style: "display:none" });
  const input = h("input", { id: "fc-chatbox-input", type: "text", placeholder: "Type a message..." });
  const sendBtn = h("button", { id: "fc-chatbox-send", text: "Send" });
  const composer = h("div", { id: "fc-chatbox-input-row" }, input, sendBtn);
  const chatChip = h("div", { class: "fc-chip", style: "display:none" });
  const chatView = h("div", { id: "fc-chat-view" }, msgSearch, messagesEl, toolbar, chatChip, composer, fileInput);

  const menu = h("div", { id: "fc-menu", style: "display:none" });
  const overlay = h("div", { id: "fc-overlay", style: "display:none" });
  const dropHint = h("div", { id: "fc-drop", style: "display:none", text: "Drop to send" });

  const chatbox = h(
    "div",
    { id: "fc-chatbox", style: "display:none" },
    header,
    listView,
    chatView,
    menu,
    overlay,
    dropHint
  );

  document.body.append(btn, chatbox);

  // Keep page hotkeys from firing while typing in the chat
  ["keydown", "keyup", "keypress"].forEach((t) => chatbox.addEventListener(t, (e) => e.stopPropagation()));

  // =====================================================================
  // Rendering
  // =====================================================================
  function render() {
    chatbox.classList.toggle("fc-dark", !!state.dark);
    chatbox.classList.toggle("fc-in-chat", view === "chat");
    const chat = view === "chat" ? getChat(activeId) : null;
    if (view === "chat" && !chat) view = "list";

    listView.style.display = view === "list" ? "flex" : "none";
    chatView.style.display = view === "chat" ? "flex" : "none";
    backBtn.style.visibility = view === "chat" ? "visible" : "hidden";
    menuBtn.style.visibility = view === "chat" ? "visible" : "hidden";
    titleEl.textContent = chat ? chat.name : "Chat Everywhere";
    if (chat && chat.type === "group") titleEl.textContent = `${chat.name} · ${chat.members.length + 1} members`;

    if (view === "list") renderTab();
    else renderMessages(chat);
    renderDraft();
  }

  function renderDraft() {
    for (const chip of [quickChip, chatChip]) {
      chip.textContent = "";
      if (!draft) {
        chip.style.display = "none";
        continue;
      }
      chip.style.display = "flex";
      chip.append(
        h("span", { class: "fc-chip-icon", text: draft.media.ytId ? "▶" : "🎞" }),
        h("span", { class: "fc-chip-name", text: draft.media.name }),
        h("span", { class: "fc-chip-hint", text: "ready to send" }),
        h("button", {
          class: "fc-chip-x",
          type: "button",
          "aria-label": "Remove attachment",
          text: "✕",
          onclick: () => {
            draft = null;
            renderDraft();
          },
        })
      );
    }
  }

  function renderTab() {
    nav.querySelectorAll(".fc-navbtn").forEach((b) => {
      const on = b.dataset.tab === tab;
      b.classList.toggle("active", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
    const searchable = tab === "chat" || tab === "groups";
    listTop.style.display = searchable ? "flex" : "none";
    newBtn.textContent = tab === "groups" ? "+ Group" : "+ Chat";
    searchChats.placeholder = tab === "groups" ? "Search groups" : tab === "chat" && chatSub === "sent" ? "Search sent messages" : "Search chats";
    refreshQuick();
    tabContent.textContent = "";
    if (tab === "chat") tabContent.append(chatSwitch());
    if (tab === "chat" && chatSub === "sent") renderSentTab();
    else if (tab === "chat") renderChatTab("dm");
    else if (tab === "groups") renderChatTab("group");
    else if (tab === "media") renderMediaTab();
    else if (tab === "shares") renderSharesTab();
    else renderToolsTab();
  }

  // ----- Quick composer -----
  function refreshQuick() {
    const show = tab === "chat" || tab === "groups";
    quickBar.style.display = show ? "flex" : "none";
    if (!show) return;
    const type = tab === "groups" ? "group" : "dm";
    // The home Chat tab is a neutral/default composer.
    // Do not automatically target the first or most recently opened chat.
    // A recipient is selected only after the user chooses a chat or presses Send.
    quickTarget = null;
    quickInput.placeholder = type === "group"
      ? "Type a message..."
      : "Type a message...";
  }

  function quickSend() {
    const text = quickInput.value.trim();
    if (!text && !draft) return;
    const type = tab === "groups" ? "group" : "dm";
    const target = quickTarget;

    if (!target) {
      modal({
        title: type === "group" ? "Name your group" : "Who is this chat with?",
        okText: "Send",
        fields:
          type === "group"
            ? [
                { name: "name", label: "Group name", placeholder: "e.g. Weekend plans" },
                { name: "members", label: "Members (comma separated)", placeholder: "Maria, Jon, Ana" },
              ]
            : [{ name: "name", label: "Contact name", placeholder: "e.g. Maria" }],
        onOk: (v) => {
          const name = v.name.trim();
          if (!name) return toast("Enter a name, then press Send again.");
          const chat = { id: uid(), type, name, members: type === "group" ? parseMembers(v.members) : [], messages: [] };
          state.chats.push(chat);
          save();
          quickInput.value = "";
          quickTarget = chat.id;
          const media = draft && draft.media;
          draft = null;
          deliver(chat.id, text, media);
          openChat(chat.id);
        },
      });
      return;
    }
    if (!getChat(target)) return toast("That chat no longer exists.");
    quickInput.value = "";
    const media = draft && draft.media;
    draft = null;
    renderDraft();
    deliver(target, text, media);
    toast(`Sent to ${getChat(target).name}`);
  }

  // ----- Chats / Sent switch -----
  function chatSwitch() {
    const seg = (id, label) =>
      h("button", {
        class: "fc-seg-btn" + (chatSub === id ? " active" : ""),
        type: "button",
        text: label,
        onclick: () => {
          chatSub = id;
          listFilter = "";
          searchChats.value = "";
          render();
        },
      });
    return h("div", { class: "fc-seg" }, seg("chats", "Chats"), seg("sent", "Sent"));
  }

  const fmtStamp = (ts) => {
    const d = new Date(ts);
    return d.toDateString() === new Date().toDateString()
      ? fmtTime(ts)
      : d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + fmtTime(ts);
  };

  // ----- Sent: every message you've sent, across all chats -----
  function renderSentTab() {
    const q = listFilter.toLowerCase();
    const items = [];
    for (const c of state.chats) for (const m of c.messages) if (m.from === ME) items.push({ c, m });
    const label = (m) => (m.media ? `${m.media.ytId ? "▶" : "📎"} ${m.media.name}` : m.card ? `🔗 ${m.card.title}` : m.text || "");
    const shown = items
      .filter(({ c, m }) => !q || label(m).toLowerCase().includes(q) || c.name.toLowerCase().includes(q))
      .sort((a, b) => b.m.ts - a.m.ts);

    if (!shown.length) {
      tabContent.append(h("div", { class: "fc-empty", text: q ? "No sent messages match your search." : "You haven't sent anything yet." }));
      return;
    }
    for (const { c, m } of shown) {
      tabContent.append(
        h(
          "div",
          { class: "fc-chat-item", title: "Open this chat", onclick: () => openChat(c.id) },
          h("div", { class: "fc-avatar", text: "↗" }),
          h(
            "div",
            { class: "fc-chat-meta" },
            h("div", { class: "fc-chat-name", text: `To ${c.name}` }),
            h("div", { class: "fc-chat-preview", text: label(m) })
          ),
          h("div", { class: "fc-chat-time", text: fmtStamp(m.ts) })
        )
      );
    }
  }

  // ----- Chat + Groups -----
  function renderChatTab(type) {
    const q = listFilter.toLowerCase();
    const chats = state.chats
      .filter((c) => c.type === type && (!q || c.name.toLowerCase().includes(q)))
      .sort((a, b) => (lastMsg(b)?.ts || 0) - (lastMsg(a)?.ts || 0));

    if (!chats.length) {
      const msg = q
        ? "Nothing matches your search."
        : type === "group"
        ? "No groups yet. Tap + Group to create one."
        : "No chats yet. Tap + Chat to start one.";
      tabContent.append(h("div", { class: "fc-empty", text: msg }));
      return;
    }
    for (const c of chats) {
      const m = lastMsg(c);
      const preview = !m ? "No messages yet" : m.media ? `${m.media.ytId ? "▶" : "📎"} ${m.media.name}` : m.card ? `🔗 ${m.card.title}` : m.text || "";
      tabContent.append(
        h(
          "div",
          { class: "fc-chat-item", onclick: () => openChat(c.id) },
          h("div", { class: "fc-avatar", text: c.type === "group" ? "👥" : c.name.charAt(0).toUpperCase() }),
          h(
            "div",
            { class: "fc-chat-meta" },
            h("div", { class: "fc-chat-name", text: c.type === "group" ? `${c.name} · ${c.members.length + 1}` : c.name }),
            h("div", { class: "fc-chat-preview", text: preview })
          ),
          h("div", { class: "fc-chat-time", text: m ? fmtTime(m.ts) : "" })
        )
      );
    }
  }

  // ----- Media: everything sent or received, across all chats -----
  function renderMediaTab() {
    const items = [];
    for (const c of state.chats) for (const m of c.messages) if (m.media) items.push({ chat: c, ts: m.ts, media: m.media });
    for (const l of state.library) items.push({ lib: l, ts: l.ts, media: l.media });
    items.sort((a, b) => b.ts - a.ts);

    tabContent.append(h("div", { class: "fc-drop-hint", text: "Drag a YouTube video, image or file here to add it." }));
    if (!items.length) {
      tabContent.append(h("div", { class: "fc-empty", text: "No media yet. Drop something here, or tap 📎 Media inside a chat." }));
      return;
    }
    const grid = h("div", { class: "fc-grid" });
    for (const { chat, lib, media: md } of items) {
      let thumb;
      if (md.ytId) {
        thumb = h(
          "button",
          { class: "fc-yt-thumb", type: "button", title: md.name, onclick: () => ytOverlay(md) },
          h("img", { src: md.dataUrl, alt: md.name, onerror: (e) => (e.target.style.display = "none") }),
          h("span", { class: "fc-yt-badge", text: "▶" })
        );
      } else if (md.mime.startsWith("image/")) thumb = h("img", { src: md.dataUrl, alt: md.name, onclick: () => lightbox(md) });
      else if (md.mime.startsWith("video/")) thumb = h("video", { src: md.dataUrl, controls: true });
      else if (md.mime.startsWith("audio/")) thumb = h("audio", { src: md.dataUrl, controls: true });
      else thumb = h("a", { class: "fc-file", href: md.dataUrl, download: md.name, text: `📄 ${md.name}` });

      const caps = chat
        ? [h("button", { class: "fc-grid-cap", title: `Open ${chat.name}`, text: chat.name, onclick: () => openChat(chat.id) })]
        : [
            h("button", {
              class: "fc-grid-cap",
              title: "Send to a chat",
              text: "Send…",
              onclick: () => pickChat("Send to", (c) => (addMessage(c.id, { media: md }), toast(`Sent to ${c.name}`))),
            }),
            h("button", {
              class: "fc-grid-cap",
              title: "Remove from Media",
              text: "Remove",
              onclick: () => {
                state.library = state.library.filter((x) => x.id !== lib.id);
                save();
                render();
              },
            }),
          ];
      grid.append(h("div", { class: "fc-grid-item" }, h("div", { class: "fc-thumb" }, thumb), h("div", { class: "fc-grid-caps" }, ...caps)));
    }
    tabContent.append(grid);
  }

  // ----- Shares: shared pages and quotes, plus quick share actions -----
  function renderSharesTab() {
    tabContent.append(
      h(
        "div",
        { class: "fc-share-actions" },
        h("button", { class: "fc-pill", text: "Share this page", onclick: () => pickChat("Send page to", (c) => sharePage(c.id)) }),
        h("button", { class: "fc-pill ghost", text: "Quote selection", onclick: () => pickChat("Send quote to", (c) => quoteSelection(c.id)) })
      )
    );
    const items = [];
    for (const c of state.chats) for (const m of c.messages) if (m.card || m.quote) items.push({ chat: c, msg: m });
    items.sort((a, b) => b.msg.ts - a.msg.ts);
    if (!items.length) {
      tabContent.append(h("div", { class: "fc-empty", text: "Nothing shared yet. Share this page or a text selection and it will be listed here." }));
      return;
    }
    for (const { chat, msg } of items) {
      const body = msg.card
        ? [
            h("div", { class: "fc-card-title", text: msg.card.title }),
            h("a", { class: "fc-card-url", href: msg.card.url, target: "_blank", rel: "noopener noreferrer", text: msg.card.url }),
          ]
        : [h("div", { class: "fc-text", text: msg.text })];
      tabContent.append(
        h(
          "div",
          { class: "fc-share-item" },
          ...body,
          h(
            "div",
            { class: "fc-share-foot" },
            h("span", { class: "fc-time", text: `${chat.name} · ${fmtTime(msg.ts)}` }),
            h("button", { class: "fc-act-vis", text: "Copy", onclick: () => copyText(msg.card ? msg.card.url : msg.text) }),
            msg.card && navigator.share ? h("button", { class: "fc-act-vis", text: "Share…", onclick: () => nativeShare(msg.card) }) : null,
            h("button", { class: "fc-act-vis", text: "Open chat", onclick: () => openChat(chat.id) })
          )
        )
      );
    }
  }

  // ----- Tools -----
  function renderToolsTab() {
    const tool = (icon, label, fn) =>
      h("button", { class: "fc-tool-card", type: "button", onclick: fn }, h("span", { class: "fc-tool-big", text: icon }), h("span", { text: label }));

    tabContent.append(
      h(
        "div",
        { class: "fc-tools-grid" },
        tool("📸", "Screenshot", () => pickChat("Send screenshot to", (c) => takeScreenshot(c.id))),
        tool("🔗", "Share this page", () => pickChat("Send page to", (c) => sharePage(c.id))),
        tool("❝", "Quote selection", () => pickChat("Send quote to", (c) => quoteSelection(c.id))),
        tool("📋", "Copy page link", () => copyText(location.href)),
        tool("⬇", "Export all chats", exportAll),
        tool(state.dark ? "☀" : "🌙", state.dark ? "Light mode" : "Dark mode", toggleDark)
      )
    );

    const out = h("div", { class: "fc-calc-out", text: "Result appears here" });
    const calcIn = h("input", { type: "text", placeholder: "e.g. 12.5 * (3 + 4)" });
    calcIn.addEventListener("input", () => {
      const expr = calcIn.value.trim();
      if (!expr) return (out.textContent = "Result appears here");
      out.textContent = /^[\d\s+\-*/().%]+$/.test(expr) ? safeCalc(expr) : "Use numbers and + - * / % ( ) only.";
    });
    tabContent.append(
      h(
        "div",
        { class: "fc-calc" },
        h("div", { class: "fc-modal-title", text: "Calculator" }),
        calcIn,
        h("div", { class: "fc-calc-row" }, out, h("button", { class: "fc-act-vis", text: "Copy", onclick: () => copyText(out.textContent) }))
      )
    );
  }

  function safeCalc(expr) {
    try {
      const v = Function(`"use strict"; return (${expr})`)();
      return Number.isFinite(v) ? String(v) : "Not a number";
    } catch (e) {
      return "Incomplete expression";
    }
  }

  function renderMessages(chat) {
    const nearBottom = messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 80;
    messagesEl.textContent = "";
    const q = msgFilter.toLowerCase();
    const msgs = chat.messages.filter((m) => !q || (m.text || "").toLowerCase().includes(q) || (m.media?.name || "").toLowerCase().includes(q));

    if (!msgs.length) {
      messagesEl.append(h("div", { class: "fc-empty", text: q ? "No messages match your search." : "No messages yet. Say hi, or attach something with 📎 Media." }));
    }
    for (const m of msgs) {
      const mine = m.from === ME;
      const bubble = h("div", { class: `fc-message ${mine ? "user" : "bot"}` });
      if (chat.type === "group" && !mine) bubble.append(h("div", { class: "fc-sender", text: m.from }));
      if (m.fwd) bubble.append(h("div", { class: "fc-fwd", text: "Forwarded" }));
      if (m.media) bubble.append(renderMedia(m.media));
      if (m.card) bubble.append(renderCard(m.card));
      if (m.text) bubble.append(h("div", { class: "fc-text", text: m.text }));
      bubble.append(
        h(
          "div",
          { class: "fc-msg-foot" },
          h("span", { class: "fc-time", text: fmtTime(m.ts) }),
          h("button", { class: "fc-act", title: "Copy", text: "Copy", onclick: () => copyMessage(m) }),
          h("button", { class: "fc-act", title: "Forward to another chat", text: "Forward", onclick: () => forwardMessage(m) }),
          h("button", { class: "fc-act", title: "Delete", text: "Delete", onclick: () => deleteMessage(chat.id, m.id) })
        )
      );
      messagesEl.append(h("div", { class: `fc-row ${mine ? "user" : "bot"}` }, bubble));
    }
    if (nearBottom || view === "chat") messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function renderMedia(media) {
    if (media.ytId) return renderYouTube(media);
    if (media.mime.startsWith("image/"))
      return h("img", { class: "fc-media", src: media.dataUrl, alt: media.name, onclick: () => lightbox(media) });
    if (media.mime.startsWith("video/")) return h("video", { class: "fc-media", src: media.dataUrl, controls: true });
    if (media.mime.startsWith("audio/")) return h("audio", { class: "fc-audio", src: media.dataUrl, controls: true });
    return h("a", { class: "fc-file", href: media.dataUrl, download: media.name, text: `📄 ${media.name}` });
  }

  function renderCard(card) {
    return h(
      "div",
      { class: "fc-card" },
      h("div", { class: "fc-card-title", text: card.title }),
      h("a", { class: "fc-card-url", href: card.url, target: "_blank", rel: "noopener noreferrer", text: card.url }),
      h(
        "div",
        { class: "fc-card-actions" },
        h("button", { class: "fc-act", text: "Copy link", onclick: () => copyText(card.url) }),
        navigator.share ? h("button", { class: "fc-act", text: "Share…", onclick: () => nativeShare(card) }) : null
      )
    );
  }

  // =====================================================================
  // Chat actions
  // =====================================================================
  function openChat(id) {
    activeId = id;
    if (getChat(id)) lastOpened[getChat(id).type] = id;
    view = "chat";
    msgFilter = "";
    msgSearchInput.value = "";
    msgSearch.style.display = "none";
    render();
    input.focus();
  }

  function addMessage(chatId, partial) {
    const chat = getChat(chatId);
    if (!chat) return;
    const msg = { id: uid(), from: ME, ts: Date.now(), ...partial };
    chat.messages.push(msg);
    save();
    render();
    if (msg.from === ME) transport.send(chat, msg);
    return msg;
  }

  // Sends text to a chat. A YouTube link goes to Media instead of the chat.
  function deliver(chatId, text, media) {
    if (media) return addMessage(chatId, { media, ...(text ? { text } : {}) });
    const vid = ytId(text);
    if (vid) {
      toast("Video added to Media");
      return addYouTube(LIB, text, vid);
    }
    addMessage(chatId, { text });
  }

  function sendText() {
    const text = input.value.trim();
    if ((!text && !draft) || !activeId) return;
    input.value = "";
    const media = draft && draft.media;
    draft = null;
    renderDraft();
    deliver(activeId, text, media);
  }

  function deleteMessage(chatId, msgId) {
    const chat = getChat(chatId);
    chat.messages = chat.messages.filter((m) => m.id !== msgId);
    save();
    render();
  }

  // =====================================================================
  // Media
  // =====================================================================
  function readAsDataUrl(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.readAsDataURL(file);
    });
  }

  // Shrink large photos so storage stays small
  async function downscale(dataUrl, maxSide = 1280) {
    const img = await new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = dataUrl;
    });
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
    if (scale === 1) return dataUrl;
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.85);
  }

  async function sendFiles(files, chatId = activeId) {
    const made = [];
    if (!chatId) return made;
    for (const file of files) {
      if (file.size > MAX_FILE_MB * 1024 * 1024) {
        toast(`${file.name} is over ${MAX_FILE_MB} MB. Choose a smaller file.`);
        continue;
      }
      try {
        let dataUrl = await readAsDataUrl(file);
        let mime = file.type || "application/octet-stream";
        if (mime.startsWith("image/") && mime !== "image/gif" && mime !== "image/svg+xml") {
          dataUrl = await downscale(dataUrl);
          if (dataUrl.startsWith("data:image/jpeg")) mime = "image/jpeg";
        }
        const media = { name: file.name || "pasted-image.png", mime, dataUrl };
        addMedia(chatId, media);
        made.push(media);
      } catch (e) {
        toast(`Couldn't read ${file.name}.`);
      }
    }
    return made;
  }

  // Adds media to a chat, or to the Media library when target is LIB.
  function addMedia(target, media) {
    if (target === LIB) {
      const item = { id: uid(), ts: Date.now(), media };
      state.library.unshift(item);
      save();
      render();
      return item;
    }
    return addMessage(target, { media });
  }

  // ----- YouTube links -----
  function ytId(u) {
    try {
      const x = new URL(u.trim());
      const host = x.hostname.replace(/^(www|m|music)\./, "");
      let id = null;
      if (host === "youtu.be") id = x.pathname.slice(1).split("/")[0];
      else if (host === "youtube.com" || host === "youtube-nocookie.com") {
        if (x.pathname === "/watch") id = x.searchParams.get("v");
        else {
          const m = x.pathname.match(/^\/(shorts|embed|live|v)\/([\w-]+)/);
          id = m && m[2];
        }
      }
      return id && /^[\w-]{6,15}$/.test(id) ? id : null;
    } catch (e) {
      return null;
    }
  }

  function ytMedia(url, id) {
    return { name: "YouTube video", mime: "video/youtube", ytId: id, url, dataUrl: `https://i.ytimg.com/vi/${id}/hqdefault.jpg` };
  }

  async function addYouTube(chatId, url, id) {
    const rec = addMedia(chatId, ytMedia(url, id));
    // Best effort: fetch the real title (the page's security policy may block this)
    try {
      const r = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`);
      if (!r.ok) return;
      const j = await r.json();
      const holder = chatId === LIB ? state.library : (getChat(chatId) || { messages: [] }).messages;
      const m = holder.find((x) => x.id === rec.id);
      if (m && j.title) {
        m.media.name = j.title;
        save();
        render();
      }
      if (j.title && draft && draft.media.ytId === id) {
        draft.media.name = j.title;
        renderDraft();
      }
    } catch (e) {
      /* keep the generic title */
    }
  }

  function ytPlayer(md) {
    return h("iframe", {
      class: "fc-yt-iframe",
      src: `https://www.youtube.com/embed/${md.ytId}?autoplay=1&rel=0`,
      allow: "autoplay; encrypted-media; picture-in-picture; fullscreen",
      allowfullscreen: true,
      referrerpolicy: "strict-origin-when-cross-origin",
      title: md.name,
    });
  }

  function renderYouTube(md) {
    const frame = h("div", { class: "fc-yt-frame" });
    frame.append(
      h("img", { src: md.dataUrl, alt: md.name, onerror: (e) => (e.target.style.display = "none") }),
      h("button", {
        class: "fc-yt-play",
        type: "button",
        "aria-label": `Play ${md.name}`,
        text: "▶",
        onclick: () => {
          frame.textContent = "";
          frame.append(ytPlayer(md));
        },
      })
    );
    return h(
      "div",
      { class: "fc-yt" },
      frame,
      h("div", { class: "fc-yt-title", text: md.name }),
      h("a", { class: "fc-yt-open", href: md.url, target: "_blank", rel: "noopener noreferrer", text: "Open on YouTube" })
    );
  }

  function ytOverlay(md) {
    overlay.textContent = "";
    overlay.className = "fc-lightbox";
    overlay.append(
      h("div", { class: "fc-yt-frame fc-yt-big" }, ytPlayer(md)),
      h("div", { class: "fc-yt-title light", text: md.name }),
      h(
        "div",
        { class: "fc-modal-actions" },
        h("a", { class: "fc-pill", href: md.url, target: "_blank", rel: "noopener noreferrer", text: "Open on YouTube" }),
        h("button", { class: "fc-pill", text: "Close", onclick: closeOverlay })
      )
    );
    overlay.style.display = "flex";
  }

  // ----- Dropped content: files, YouTube links, other links, image URLs -----
  async function ingestDrop(files, url, chatId) {
    if (files.length) return sendFiles(files, chatId);
    if (!url) return toast("Nothing to add from that drop.");
    const id = ytId(url);
    if (id) return addYouTube(chatId, url, id);
    if (/\.(png|jpe?g|gif|webp|avif)(\?|#|$)/i.test(url)) {
      try {
        const blob = await (await fetch(url)).blob();
        const name = decodeURIComponent(url.split("/").pop().split(/[?#]/)[0]) || "image";
        return sendFiles([new File([blob], name, { type: blob.type })], chatId);
      } catch (e) {
        /* blocked by the page's policy: share it as a link instead */
      }
    }
    if (chatId === LIB) return toast("Media only takes videos, images and files. To share a link, drop it inside a chat.");
    let host = url;
    try {
      host = new URL(url).hostname;
    } catch (e) {}
    addMessage(chatId, { card: { title: host, url } });
  }

  function dropUrl(dt) {
    const fromList = (dt.getData("text/uri-list") || "").split(/\r?\n/).find((l) => l && !l.startsWith("#"));
    const text = (dt.getData("text/plain") || "").trim();
    return fromList || (/^https?:\/\/\S+$/i.test(text) ? text : "");
  }

  function lightbox(media) {
    overlay.textContent = "";
    overlay.className = "fc-lightbox";
    overlay.append(
      h("img", { src: media.dataUrl, alt: media.name }),
      h("a", { class: "fc-pill", href: media.dataUrl, download: media.name, text: "Download" }),
      h("button", { class: "fc-pill", text: "Close", onclick: closeOverlay })
    );
    overlay.style.display = "flex";
  }

  // =====================================================================
  // Shares
  // =====================================================================
  function sharePage(chatId = activeId) {
    addMessage(chatId, { card: { title: document.title || location.hostname, url: location.href } });
  }

  function quoteSelection(chatId = activeId) {
    const sel = String(window.getSelection()).trim();
    if (!sel) return toast("Select some text on the page first.");
    addMessage(chatId, { quote: true, text: `“${sel.slice(0, 1000)}”\n— ${document.title || location.hostname}` });
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      toast("Copied");
    } catch (e) {
      toast("Couldn't copy. The page blocked clipboard access.");
    }
  }

  function copyMessage(m) {
    copyText(m.text || m.card?.url || m.media?.url || m.media?.name || "");
  }

  async function nativeShare(card) {
    try {
      await navigator.share({ title: card.title, url: card.url });
    } catch (e) {
      /* user cancelled */
    }
  }

  function forwardMessage(m) {
    pickChat("Forward to", (target) => {
      addMessage(target.id, { text: m.text, media: m.media, card: m.card, fwd: true });
      toast(`Forwarded to ${target.name}`);
    });
  }

  function downloadJson(name, obj) {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
    const a = h("a", { href: URL.createObjectURL(blob), download: name });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  const slimChat = (chat) => ({
    ...chat,
    messages: chat.messages.map((m) => (m.media ? { ...m, media: { name: m.media.name, mime: m.media.mime, url: m.media.url } } : m)),
  });

  function exportChat() {
    const chat = getChat(activeId);
    downloadJson(`${chat.name.replace(/\W+/g, "-")}.json`, slimChat(chat));
  }

  function exportAll() {
    downloadJson("floating-chat-export.json", { exportedAt: new Date().toISOString(), chats: state.chats.map(slimChat) });
  }

  // =====================================================================
  // Tools
  // =====================================================================
  // Uses the browser's own screen-capture picker, so no background script is needed.
  async function takeScreenshot(chatId = activeId) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      return toast("Screenshots aren't supported on this page.");
    }
    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({ video: true, preferCurrentTab: true });
    } catch (e) {
      return toast("Screenshot cancelled or blocked.");
    }
    let dataUrl = null;
    try {
      chatbox.style.visibility = "hidden";
      btn.style.visibility = "hidden";
      const video = h("video", { muted: true, playsinline: true });
      video.srcObject = stream;
      await video.play();
      await new Promise((r) => setTimeout(r, 300));
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d").drawImage(video, 0, 0);
      dataUrl = await downscale(canvas.toDataURL("image/jpeg", 0.85));
    } catch (e) {
      dataUrl = null;
    } finally {
      stream.getTracks().forEach((t) => t.stop());
      chatbox.style.visibility = "";
      btn.style.visibility = "";
    }
    if (!dataUrl) return toast("Couldn't capture the screen.");
    addMessage(chatId, { media: { name: `screenshot-${Date.now()}.jpg`, mime: "image/jpeg", dataUrl } });
  }

  function clearChat(chatId = activeId, silent = false) {
    const chat = getChat(chatId);
    if (!chat) return;
    const doIt = () => {
      chat.messages = [];
      save();
      render();
    };
    if (silent) return doIt();
    confirmBox(`Clear all messages in “${chat.name}”?`, "Clear", doIt);
  }

  function deleteChat() {
    const chat = getChat(activeId);
    confirmBox(`Delete “${chat.name}” and its messages?`, "Delete", () => {
      state.chats = state.chats.filter((c) => c.id !== chat.id);
      activeId = null;
      view = "list";
      save();
      render();
    });
  }

  function editGroup() {
    const chat = getChat(activeId);
    modal({
      title: "Group details",
      okText: "Save",
      fields: [
        { name: "name", label: "Group name", value: chat.name },
        { name: "members", label: "Members (comma separated)", value: chat.members.join(", ") },
      ],
      onOk: (v) => {
        if (v.name.trim()) chat.name = v.name.trim();
        chat.members = parseMembers(v.members);
        save();
        render();
      },
    });
  }

  function toggleMsgSearch() {
    const show = msgSearch.style.display === "none";
    msgSearch.style.display = show ? "block" : "none";
    msgFilter = "";
    msgSearchInput.value = "";
    if (show) msgSearchInput.focus();
    render();
  }

  function buildMenu() {
    menu.textContent = "";
    const items = [];
    if (view === "chat") {
      const chat = getChat(activeId);
      items.push(["🔍 Search in chat", toggleMsgSearch], ["⬇ Export chat", exportChat]);
      if (chat.type === "group") items.push(["👥 Group details", editGroup]);
      items.push(["🧹 Clear messages", () => clearChat()]);
      items.push(["🗑 Delete chat", deleteChat]);
    }
    items.push([state.dark ? "☀ Light mode" : "🌙 Dark mode", toggleDark]);
    for (const [label, fn] of items) {
      menu.append(
        h("button", {
          class: "fc-menu-item",
          text: label,
          onclick: () => {
            menu.style.display = "none";
            fn();
          },
        })
      );
    }
  }

  function toggleDark() {
    state.dark = !state.dark;
    save();
    render();
  }

  // =====================================================================
  // Groups / new chats
  // =====================================================================
  const parseMembers = (s) =>
    (s || "")
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean);

  function newChat() {
    modal({
      title: "New chat",
      okText: "Start",
      fields: [{ name: "name", label: "Contact name", placeholder: "e.g. Maria" }],
      onOk: (v) => {
        const name = v.name.trim();
        if (!name) return toast("Enter a name.");
        const chat = { id: uid(), type: "dm", name, members: [], messages: [] };
        tab = "chat";
        state.chats.push(chat);
        save();
        openChat(chat.id);
      },
    });
  }

  function newGroup() {
    modal({
      title: "New group",
      okText: "Create",
      fields: [
        { name: "name", label: "Group name", placeholder: "e.g. Weekend plans" },
        { name: "members", label: "Members (comma separated)", placeholder: "Maria, Jon, Ana" },
      ],
      onOk: (v) => {
        const name = v.name.trim();
        if (!name) return toast("Enter a group name.");
        const chat = { id: uid(), type: "group", name, members: parseMembers(v.members), messages: [] };
        tab = "groups";
        state.chats.push(chat);
        save();
        openChat(chat.id);
      },
    });
  }

  // =====================================================================
  // Overlay widgets: modal, confirm, chat picker, toast
  // =====================================================================
  function closeOverlay() {
    overlay.style.display = "none";
    overlay.textContent = "";
    overlay.className = "";
  }

  function modal({ title, fields, okText, onOk }) {
    overlay.textContent = "";
    overlay.className = "fc-modal-wrap";
    const inputs = {};
    const form = h("div", { class: "fc-modal" }, h("div", { class: "fc-modal-title", text: title }));
    for (const f of fields) {
      inputs[f.name] = h("input", { type: "text", value: f.value || "", placeholder: f.placeholder || "" });
      form.append(h("label", { class: "fc-label" }, f.label, inputs[f.name]));
    }
    const ok = () => {
      const values = Object.fromEntries(Object.entries(inputs).map(([k, el]) => [k, el.value]));
      closeOverlay();
      onOk(values);
    };
    form.append(
      h(
        "div",
        { class: "fc-modal-actions" },
        h("button", { class: "fc-pill ghost", text: "Cancel", onclick: closeOverlay }),
        h("button", { class: "fc-pill", text: okText, onclick: ok })
      )
    );
    form.addEventListener("keydown", (e) => {
      if (e.key === "Enter") ok();
      if (e.key === "Escape") closeOverlay();
    });
    overlay.append(form);
    overlay.style.display = "flex";
    Object.values(inputs)[0].focus();
  }

  function confirmBox(text, okText, onOk) {
    overlay.textContent = "";
    overlay.className = "fc-modal-wrap";
    overlay.append(
      h(
        "div",
        { class: "fc-modal" },
        h("div", { class: "fc-modal-title", text }),
        h(
          "div",
          { class: "fc-modal-actions" },
          h("button", { class: "fc-pill ghost", text: "Cancel", onclick: closeOverlay }),
          h("button", { class: "fc-pill danger", text: okText, onclick: () => (closeOverlay(), onOk()) })
        )
      )
    );
    overlay.style.display = "flex";
  }

  function pickChat(title, cb) {
    overlay.textContent = "";
    overlay.className = "fc-modal-wrap";
    const list = h("div", { class: "fc-pick-list" });
    if (!state.chats.length) list.append(h("div", { class: "fc-empty", text: "No chats yet. Create one from the Chat or Groups tab first." }));
    for (const c of state.chats) {
      list.append(h("button", { class: "fc-menu-item", text: (c.type === "group" ? "👥 " : "") + c.name, onclick: () => (closeOverlay(), cb(c)) }));
    }
    overlay.append(
      h("div", { class: "fc-modal" }, h("div", { class: "fc-modal-title", text: title }), list, h("div", { class: "fc-modal-actions" }, h("button", { class: "fc-pill ghost", text: "Cancel", onclick: closeOverlay })))
    );
    overlay.style.display = "flex";
  }

  let toastTimer;
  function toast(text) {
    chatbox.querySelectorAll(".fc-toast").forEach((t) => t.remove());
    const t = h("div", { class: "fc-toast", role: "status", text });
    chatbox.append(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.remove(), 2600);
  }

  // =====================================================================
  // Events
  // =====================================================================
  function toggleChat() {
    isOpen = !isOpen;
    chatbox.style.display = isOpen ? "flex" : "none";
    if (isOpen && view === "chat") input.focus();
  }

  btn.addEventListener("click", toggleChat);
  closeBtn.addEventListener("click", () => {
    isOpen = false;
    chatbox.style.display = "none";
  });
  backBtn.addEventListener("click", () => {
    view = "list";
    activeId = null;
    render();
  });
  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (menu.style.display === "none") {
      buildMenu();
      menu.style.display = "flex";
    } else menu.style.display = "none";
  });
  chatbox.addEventListener("click", (e) => {
    if (!menu.contains(e.target)) menu.style.display = "none";
    if (e.target === overlay) closeOverlay();
  });

  newBtn.addEventListener("click", () => (tab === "groups" ? newGroup() : newChat()));
  searchChats.addEventListener("input", () => {
    listFilter = searchChats.value;
    renderTab();
  });
  msgSearchInput.addEventListener("input", () => {
    msgFilter = msgSearchInput.value;
    render();
  });

  quickSendBtn.addEventListener("click", quickSend);
  quickInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      quickSend();
    }
  });
  sendBtn.addEventListener("click", sendText);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendText();
    }
  });

  fileInput.addEventListener("change", () => {
    sendFiles([...fileInput.files]);
    fileInput.value = "";
  });
  input.addEventListener("paste", (e) => {
    const files = [...(e.clipboardData?.files || [])];
    if (files.length) {
      e.preventDefault();
      sendFiles(files);
    }
  });

  // The message composer is also a dedicated drop target.
  // YouTube links and video files are staged in the message box so they can
  // still be sent with the Send button. The existing chatbox handler remains
  // as a fallback for drops elsewhere in the panel.
  let quickDragDepth = 0;
  quickBar.addEventListener("dragenter", (e) => {
    e.preventDefault();
    e.stopPropagation();
    quickDragDepth++;
    quickBar.classList.add("fc-drop-target");
  });
  quickBar.addEventListener("dragover", (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
    quickBar.classList.add("fc-drop-target");
  });
  quickBar.addEventListener("dragleave", (e) => {
    e.preventDefault();
    e.stopPropagation();
    quickDragDepth = Math.max(0, quickDragDepth - 1);
    if (!quickDragDepth) quickBar.classList.remove("fc-drop-target");
  });
  quickBar.addEventListener("drop", (e) => {
    e.preventDefault();
    e.stopPropagation();
    quickDragDepth = 0;
    quickBar.classList.remove("fc-drop-target");

    const files = [...e.dataTransfer.files];
    const url = dropUrl(e.dataTransfer);
    const videos = files.filter((f) => (f.type || "").startsWith("video/"));
    const rest = files.filter((f) => !(f.type || "").startsWith("video/"));
    const yt = !files.length && url && ytId(url) ? url : "";

    if (videos.length) {
      ingestDrop(videos, "", LIB).then((made) => {
        if (made && made[0]) {
          draft = { media: { ...made[0] } };
          renderDraft();
          toast("Video added to the message. Press Send.");
        }
      });
    }

    if (yt) {
      draft = { media: ytMedia(yt, ytId(yt)) };
      ingestDrop([], yt, LIB);
      renderDraft();
      toast("YouTube video added to the message. Press Send.");
    }

    // Keep the existing behavior for non-video files/links.
    if (!videos.length && !yt && rest.length) {
      ingestDrop(rest, "", LIB);
    }
  });

  // Drag and drop files onto the chat
  chatbox.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropHint.textContent = view === "chat" ? "Drop to send" : "Drop to add to Media";
    dropHint.style.display = "flex";
  });
  chatbox.addEventListener("dragleave", (e) => {
    if (!chatbox.contains(e.relatedTarget)) dropHint.style.display = "none";
  });
  chatbox.addEventListener("drop", (e) => {
    e.preventDefault();
    dropHint.style.display = "none";
    // dataTransfer is only readable during the event, so grab everything now
    const files = [...e.dataTransfer.files];
    const url = dropUrl(e.dataTransfer);

    const videos = files.filter((f) => (f.type || "").startsWith("video/"));
    const rest = files.filter((f) => !(f.type || "").startsWith("video/"));
    const yt = !files.length && url && ytId(url) ? url : "";
    const inChat = view === "chat" && activeId;
    const hasMessageBox = inChat || tab === "chat" || tab === "groups";

    // Videos (YouTube links or video files) always go to Media, never straight into a chat.
    // Where there is a message box they are also staged in it, ready to send.
    if (videos.length || yt) {
      if (videos.length) ingestDrop(videos, "", LIB).then((made) => made && made[0] && (draft = { media: { ...made[0] } }, renderDraft()));
      if (yt) {
        draft = { media: ytMedia(yt, ytId(yt)) };
        ingestDrop([], yt, LIB);
      }
      if (hasMessageBox) {
        toast("Added to Media. Press Send to send it too.");
        render();
      } else {
        toast("Added to Media");
        tab = "media";
        view = "list";
        activeId = null;
        render();
      }
      if (!rest.length) return;
    }

    // Everything else: into the open chat, or into Media
    const restUrl = files.length ? "" : url;
    if (inChat) return ingestDrop(rest, restUrl, activeId);
    if (tab !== "media" && !hasMessageBox) {
      tab = "media";
      render();
    }
    ingestDrop(rest, restUrl, LIB);
  });

  // =====================================================================
  // Go
  // =====================================================================
  render();
  load();
})();